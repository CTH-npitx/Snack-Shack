# Calculator Reqrirments

1. Include a "numpad" with a button for each digit 0-9 
2. Include buttons for + , - , * , / , % , and = 
3. Include a Clear button, and an Exit button 
4. Include a Text Box for numbers/calculations 
5. Users must be able to enter a number one digit at a time 
6. Pressing a math symbol displays it to the right of the currently entered number  
7. Pressing a math symbol with no number entered displays an error message 
8. After the error is displayed, clear the calculation text box 
9. Pressing = with a number, math symbol, and another number calculates the result, and displays it in the calculation text box  
10. Pressing = without a valid equation in the calculation box displays an error 
11. After the equation is calculated, users should be able to perform further calculations on the result. 
12. Pressing Clear clears the calculation box and wipes any stored data 
13. Pressing Exit exits the program 