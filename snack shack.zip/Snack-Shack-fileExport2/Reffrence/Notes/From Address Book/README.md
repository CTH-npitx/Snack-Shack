# AdressBook
This is the readme for the address book.

what does it do, you ask? well, I've been trying to figure that one out. Far as I can tell, it's a book that addresses you.
but... that doesn't make sense, does it? I don't think it does, but I could be wrong.
 
