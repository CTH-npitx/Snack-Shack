##Notes on shortcut changes
I noticed a minor flaw within the shortcuts, so I decided to check each one, even the ones I knew for a fact. Found some interesting stuff!

|Command Checked|What changed|Reason| Note|
| ---    | ---   | ---     | --- |
| save | nothing | it was correct, as I knew |I knew this one was correct, but as I was unsure about one command, and checking another, I figured "might as well check them all"|
|||||
|open|nothing|once again correct| I was pretty sure, but not as sure, about this one. But, after double checking, I now know it's correct |
|||||
|exit|changed from F14 to F4|alt+f4 is exit, not alt+14|So, for some reason I thought it was alt+F14. But, I noticed my computer (and many others) only have F1 to F12. So, I realized I might be wrong, and double checked. Turned out it's alt+f4. In fact, it was this very observation which made me decide to check all the shortcut commands, even ones I knew for a fact!|
|||||
|save as|changed to f12|Looked up what was used in word and such|apparently word uses F12|this was surprising and didn't make sense|
|save as| changed to ctrl+shift+s|turns out this is the normal standard|found that while older programs use f12, that never caught on, so only some older applications use it. Most non-microsoft products use ctrl+shift+s. Guess that standard didin't catch on when they made it!|
