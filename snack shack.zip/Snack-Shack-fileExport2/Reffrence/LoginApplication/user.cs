﻿using System;

public class user
{
    internal string username;
    internal string password;
    internal string secQuest;
    internal string secAnswer;

}