﻿namespace snackShack
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_main));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.num_snackCost = new System.Windows.Forms.NumericUpDown();
            this.picBox_icon = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_nameInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgv_invent = new System.Windows.Forms.DataGridView();
            this.col_snaName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_snaPri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_snaIcon = new System.Windows.Forms.DataGridViewImageColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.clearInputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_snackCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_icon)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_invent)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.btn_appClose);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.addToolStripMenuItem,
            this.clearInputToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Enabled = false;
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.addToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.btn_addItem_Click);
            // 
            // num_snackCost
            // 
            this.num_snackCost.DecimalPlaces = 2;
            this.num_snackCost.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_snackCost.Location = new System.Drawing.Point(47, 66);
            this.num_snackCost.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.num_snackCost.Name = "num_snackCost";
            this.num_snackCost.Size = new System.Drawing.Size(75, 20);
            this.num_snackCost.TabIndex = 4;
            this.toolTip1.SetToolTip(this.num_snackCost, "Input Price");
            this.num_snackCost.ValueChanged += new System.EventHandler(this.inpEnty_complete);
            // 
            // picBox_icon
            // 
            this.picBox_icon.Image = global::snackShack.Properties.Resources.VendingMachine;
            this.picBox_icon.InitialImage = global::snackShack.Properties.Resources.VendingMachine;
            this.picBox_icon.Location = new System.Drawing.Point(6, 19);
            this.picBox_icon.Name = "picBox_icon";
            this.picBox_icon.Size = new System.Drawing.Size(235, 229);
            this.picBox_icon.TabIndex = 5;
            this.picBox_icon.TabStop = false;
            this.toolTip1.SetToolTip(this.picBox_icon, "Image Input");
            this.picBox_icon.Click += new System.EventHandler(this.picBox_icon_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(501, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(299, 398);
            this.panel1.TabIndex = 6;
            this.panel1.MouseLeave += new System.EventHandler(this.inpEnty_complete);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.num_snackCost);
            this.groupBox2.Controls.Add(this.txt_nameInput);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(151, 100);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Snack Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Name";
            // 
            // txt_nameInput
            // 
            this.txt_nameInput.Location = new System.Drawing.Point(47, 35);
            this.txt_nameInput.Name = "txt_nameInput";
            this.txt_nameInput.Size = new System.Drawing.Size(100, 20);
            this.txt_nameInput.TabIndex = 7;
            this.toolTip1.SetToolTip(this.txt_nameInput, "Input Name");
            this.txt_nameInput.TextChanged += new System.EventHandler(this.inpEnty_complete);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cost";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.picBox_icon);
            this.groupBox1.Location = new System.Drawing.Point(43, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(245, 259);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Snack Icon";
            // 
            // dgv_invent
            // 
            this.dgv_invent.AllowUserToAddRows = false;
            this.dgv_invent.AllowUserToDeleteRows = false;
            this.dgv_invent.AllowUserToResizeColumns = false;
            this.dgv_invent.AllowUserToResizeRows = false;
            this.dgv_invent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_invent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_invent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_snaName,
            this.col_snaPri,
            this.col_snaIcon});
            this.dgv_invent.Dock = System.Windows.Forms.DockStyle.Left;
            this.dgv_invent.Location = new System.Drawing.Point(0, 24);
            this.dgv_invent.MultiSelect = false;
            this.dgv_invent.Name = "dgv_invent";
            this.dgv_invent.ReadOnly = true;
            this.dgv_invent.RowHeadersVisible = false;
            this.dgv_invent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_invent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_invent.Size = new System.Drawing.Size(503, 404);
            this.dgv_invent.TabIndex = 3;
            this.toolTip1.SetToolTip(this.dgv_invent, "Table");
            // 
            // col_snaName
            // 
            this.col_snaName.HeaderText = "Name of Snack";
            this.col_snaName.Name = "col_snaName";
            this.col_snaName.ReadOnly = true;
            // 
            // col_snaPri
            // 
            this.col_snaPri.HeaderText = "Price of Snack";
            this.col_snaPri.Name = "col_snaPri";
            this.col_snaPri.ReadOnly = true;
            // 
            // col_snaIcon
            // 
            this.col_snaIcon.HeaderText = "Icon of Snack";
            this.col_snaIcon.MinimumWidth = 225;
            this.col_snaIcon.Name = "col_snaIcon";
            this.col_snaIcon.ReadOnly = true;
            this.col_snaIcon.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_snaIcon.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // clearInputToolStripMenuItem
            // 
            this.clearInputToolStripMenuItem.Name = "clearInputToolStripMenuItem";
            this.clearInputToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.clearInputToolStripMenuItem.Text = "Clear Input";
            this.clearInputToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgv_invent);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Snack Shack";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_close);
            this.Load += new System.EventHandler(this.frmMain_load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_snackCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_icon)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_invent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown num_snackCost;
        private System.Windows.Forms.PictureBox picBox_icon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_nameInput;
        private System.Windows.Forms.DataGridView dgv_invent;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_snaName;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_snaPri;
        private System.Windows.Forms.DataGridViewImageColumn col_snaIcon;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem clearInputToolStripMenuItem;
    }
}

