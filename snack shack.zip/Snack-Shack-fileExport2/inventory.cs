﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace snackShack
{
    internal class inventory //the class that stores the inventory
    {
        internal string name; //name of snack
        internal string imagePath; //path of image
        internal decimal cost; //cost of snack
        internal int index; //the index of the entry
    }
}