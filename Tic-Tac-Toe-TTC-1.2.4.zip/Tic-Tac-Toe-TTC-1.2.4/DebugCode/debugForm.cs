﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeProject.DebugCode
{
    public partial class frm_debug : Form
    {
        public frm_debug()
        {
            InitializeComponent();
        }

        private void frm_debug_Load(object sender, EventArgs e)
        {

        }
    }
}
