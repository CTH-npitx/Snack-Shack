Create a UI that will:
	-accept the input of the snack name, cost, and image. 
	-Display the snacks as they are added, including the image.
	-allow selecting and editing of entries
	
Data should be written to disk and confirm overwrite before writing. Data should be written when the form is closed. 

Use the OpenFileDialogue to browse for images.
	trigger? not sure source input. Determine later
Use the FormClosing event to trigger writing the data to disk.
	Detailed? Simple Warning Thing?
Use the StatusStrip to display the number of records read/written and any error messages that arise.
	??