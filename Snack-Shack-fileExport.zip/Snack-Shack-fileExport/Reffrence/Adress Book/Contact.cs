﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdressBook
{
    internal class Contact
    {
        internal string firstname; //first name
        internal string lastname; //last name
        internal string email; //e-mail address
        internal string phone; //phone number
        internal bool buisness; //buisness
        internal string notes; //notes about contact
        internal int index; //the index of the entry
    }
}
