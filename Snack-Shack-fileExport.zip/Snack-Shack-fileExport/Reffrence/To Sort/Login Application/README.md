Login Application Features:

Allow Editing of Log Entries

